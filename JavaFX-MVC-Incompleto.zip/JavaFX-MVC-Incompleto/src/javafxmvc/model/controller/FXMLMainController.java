/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxmvc.model.controller;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.AnchorPane;


/**
 * FXML Controller class
 *
 * @author Dell
 */
public class FXMLMainController implements Initializable {

    @FXML
    private MenuItem menuCadastropedido;
    @FXML
    private MenuItem menuCadastrocliente;

    @FXML
    private MenuItem menuListarpedido;
    @FXML
    private MenuItem menuListarcliente;

    @FXML
    private MenuItem buscarpedido;
    @FXML
    private MenuItem buscarcliente;

    @FXML
    private MenuItem buscardetalhepedido;
    @FXML
    private AnchorPane MainanchorPane;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }   
    
    @FXML
    public void handleMenuItemCadastrosClientes() throws IOException {
        AnchorPane a = (AnchorPane) FXMLLoader.load(getClass().getResource("/javafxmvc/view/FXMLAnchorPaneCadastrosClientesController.fxml"));
MainanchorPane.getChildren().setAll(a);
    }

}
