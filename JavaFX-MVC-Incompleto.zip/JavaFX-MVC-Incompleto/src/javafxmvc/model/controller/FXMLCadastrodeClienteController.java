/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxmvc.model.controller;

import java.net.URL;
import java.sql.Connection;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafxmvc.model.dao.ClienteDAO;
import javafxmvc.model.database.Conexao;
import javafxmvc.model.domain.Customers;

/**
 * FXML Controller class
 *
 * @author Dell
 */
public class FXMLCadastrodeClienteController implements Initializable {

    @FXML
    private Label tableFax;

    @FXML
    private Label tableContactTitle;

    @FXML
    private Label tableCountry;

    @FXML
    private Label labelContactname;
    @FXML
    private Label labelnameCompany;
    @FXML
    private Label labelIDcliente;
    @FXML
    private Button buttonInsert;

    @FXML
    private Button buttonDelete;

    @FXML
    private Button buttonAlter;
     
    @FXML
   private TableColumn <Customers,String> tableviewClientecompany;

    @FXML
   private TableColumn <Customers,String> tableviewClienteID;
    
    @FXML
   private TableColumn <Customers,String> tableviewNomeContato;
    @FXML
   private TableView <Customers> ViewCliente;
    private List<Customers>listaCliente;
    private ObservableList<Customers> observableListClientes;
    
    ///manipulaçao do banco de dados
    
    private final Connection con= Conexao.conectar();
   private final ClienteDAO clienteDao= new ClienteDAO();
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      loadTableviewClientes();
      clienteDao.setConnection(con);
    }
public void loadTableviewClientes(){

tableviewClientecompany.setCellValueFactory(new PropertyValueFactory<>("CompanyName"));
tableviewNomeContato.setCellValueFactory(new PropertyValueFactory<>("ContactName"));
listaCliente = clienteDao.listar();
observableListClientes=FXCollections.observableArrayList(listaCliente);
ViewCliente.setItems(observableListClientes);
}
}
