/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxmvc.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafxmvc.model.database.Conexao;

import javafxmvc.model.domain.Orders;

public class OrdersDAO extends Orders {
 private Connection con;

    public Connection getConnection() {
        return con;
    }

    public void setConnection(Connection connection) {
        this.con = connection;
    }
    //deveria ter os detalhes tb ---::c:MARCIO FALOU QUE QUANDO SELECIONAR O PEDIDO X DEVE SER COLOCADO AS INFORMAÇOES ESPECIFICAS DELE FAZER OUTRO DAO SOBRE ISSO TB 
    public List<Orders> OrdersList() {
        List<Orders> order = new ArrayList<Orders>();
        String sql = "SELECT * FROM Orders;";
        try {
            PreparedStatement smt = con.prepareStatement(sql);
            ResultSet rs = smt.executeQuery();
            while (rs.next()) {
                Orders pedido = new Orders();
                //acho que isso que vai ser usado para poder deletar um customer ou nao 
                //é serial se ele for ID ele vai colocar defaul no  insert 
                pedido.setOrderID(rs.getInt("OrderID"));
                pedido.setCustomerID(rs.getInt("CustomerID"));
                pedido.setEmployeeID(rs.getInt("EmployeeID"));

                pedido.setOrderDate(rs.getTimestamp("OrderDate"));
                pedido.setRequiredDate(rs.getTimestamp("RequiredDate"));
                pedido.setShippedDate(rs.getTimestamp("ShippedDate"));

                pedido.setShipVia(rs.getInt("ShipVia"));
                pedido.setFreight(rs.getBigDecimal("Freight"));

                pedido.setShipName(rs.getString("ShipName"));

                pedido.setShipAddress(rs.getString("ShipAddress"));
                pedido.setShipCity(rs.getString("ShipCity"));
                pedido.setShipRegion(rs.getString("ShipRegion"));

                pedido.setShipPostalCode(rs.getString("ShipPostalCode"));

                pedido.setShipCountry(rs.getString("ShipCountry"));
            }

        } catch (SQLException e) {
            Logger.getLogger(OrdersDAO.class.getName()).log(Level.SEVERE, null, e);
            //throw new RuntimeException(e);

        }
        return order;
    }
    //especifico quando selecionado um determinado order 

    public boolean OrdersInsert(Orders order) {//  /1   /2     /3         /4     /5         /6           /7    /8        /9        /10             /11
        String sql = "INSERT INTO  Orders(OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES (?,?,?,?,?,?,?,?,?,?,?);";

        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            //é serial se ele for ID ele vai colocar defaul no  insert 
            stmt.setTimestamp(1, order.getOrderDate());
            stmt.setTimestamp(2, order.getRequiredDate());
            stmt.setTimestamp(3, order.getShippedDate());
            stmt.setInt(4, order.getShipVia());
            stmt.setBigDecimal(5, order.getFreight());
            stmt.setString(6, order.getShipName());
            stmt.setString(7, order.getShipRegion());
            stmt.setString(8, order.getShipPostalCode());
            stmt.setString(9, order.getShipCountry());

            stmt.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(OrdersDAO.class.getName()).log(Level.SEVERE, null, ex);

            return false;
        }
    }

    public Orders buscarOrders(Orders pedido) {
        String sql = "SELECT * FROM Orders WHERE CustomerID=?;";
        Orders retorno = new Orders();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, pedido.getOrderID());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {

                pedido.setCustomerID(rs.getInt("CustomerID"));
                pedido.setEmployeeID(rs.getInt("EmployeeID"));

                pedido.setOrderDate(rs.getTimestamp("OrderDate"));
                pedido.setRequiredDate(rs.getTimestamp("RequiredDate"));
                pedido.setShippedDate(rs.getTimestamp("ShippedDate"));

                pedido.setShipVia(rs.getInt("ShipVia"));
                pedido.setFreight(rs.getBigDecimal("Freight"));

                pedido.setShipName(rs.getString("ShipName"));

                pedido.setShipAddress(rs.getString("ShipAddress"));
                pedido.setShipCity(rs.getString("ShipCity"));
                pedido.setShipRegion(rs.getString("ShipRegion"));

                pedido.setShipPostalCode(rs.getString("ShipPostalCode"));

                pedido.setShipCountry(rs.getString("ShipCountry"));

                retorno = pedido;
            }
        } catch (SQLException ex) {
            Logger.getLogger(OrdersDAO.class.getName()).log(Level.SEVERE, null, ex);
            //nao encontrando mensagem
        }
        return retorno;
    }

}
