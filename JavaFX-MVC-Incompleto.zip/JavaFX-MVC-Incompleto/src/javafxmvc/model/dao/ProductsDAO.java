/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxmvc.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafxmvc.model.database.Conexao;
import javafxmvc.model.domain.Products;

/**
 *
 * @author Dell
 */
public class ProductsDAO {
 private Connection con;

    public Connection getConnection() {
        return con;
    }

    public void setConnection(Connection connection) {
        this.con = connection;
    }
    public List<Products> productsList() {
        List<Products> orderdetailsList = new ArrayList<Products>();
        String sql = "SELECT * FROM Products;";
        try {
            PreparedStatement stmt = con.prepareStatement(sql);//os pedidos que estao no banco de dados
            ResultSet rs = stmt.executeQuery();//armazenar o resultado deste select

            while (rs.next()) {
                Products orderdel = new Products();
                orderdel.setProductID(rs.getInt("ProductID"));
                orderdel.setProductName(rs.getString("ProductName"));
                orderdel.setSupplierID(rs.getInt("SupplierID"));
                orderdel.setCategoryID(rs.getInt("CategoryID"));
                orderdel.setQuantityPerUnit(rs.getString("QuantityPerUnit"));
                orderdel.setUnitPrice(rs.getBigDecimal("UnitPrice"));
                orderdel.setDiscontinued(rs.getBoolean("Discontinued"));
                orderdel.setUnitsInStock(rs.getShort("UnitsInStock"));
                orderdel.setUnitsOnOrder(rs.getShort("UnitsOnOrder"));
                orderdel.setReorderLevel(rs.getShort("ReorderLevel"));
                orderdetailsList.add(orderdel);
            }
        } catch (SQLException e) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, e);
            
        }
        return orderdetailsList;
    }

}
