package javafxmvc.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafxmvc.model.domain.OrderDetails;

public class OrderDetailsDAO {
 private Connection con;

    public Connection getConnection() {
        return con;
    }

    public void setConnection(Connection connection) {
        this.con = connection;
    }
    //é algum produto relacionado com alguma compra 
    public List<OrderDetails> OrderDetailsList() {
 
        List<OrderDetails> orderdetailsList = new ArrayList<OrderDetails>();
        String sql = "SELECT * FROM OrderDetails ;";
        try {
            PreparedStatement stmt = con.prepareStatement(sql);//os pedidos que estao no banco de dados
            ResultSet rs = stmt.executeQuery();//armazenar o resultado deste select
            while (rs.next()) {

                OrderDetails pedidosDetalhe = new OrderDetails();
                pedidosDetalhe.setOrderID(rs.getInt("OrderID"));
                pedidosDetalhe.setProductID(rs.getInt("ProductID"));
                pedidosDetalhe.setUnitPrice(rs.getBigDecimal("UnitPrice"));
                pedidosDetalhe.setQuantity(rs.getShort("Quantity"));
                pedidosDetalhe.setDiscount(rs.getFloat("Discount"));

                orderdetailsList.add(pedidosDetalhe);

            }

        } catch (SQLException e) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, e);
        }
        return orderdetailsList;
    }

    public OrderDetails buscarDetalhes(OrderDetails pedidodetail) {
        String sql = "SELECT * FROM OrderDetails WHERE OrderID=?;";
        OrderDetails retorno = new OrderDetails();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, pedidodetail.getOrderID());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                pedidodetail.setOrderID(rs.getInt("OrderID"));
                pedidodetail.setProductID(rs.getInt("ProductID"));
                pedidodetail.setUnitPrice(rs.getBigDecimal("UnitPrice"));
                pedidodetail.setQuantity(rs.getShort("Quantity"));
                pedidodetail.setDiscount(rs.getFloat("Discount"));
                retorno = pedidodetail;
            }
        } catch (SQLException ex) {
            Logger.getLogger(OrderDetails.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
    }
}
