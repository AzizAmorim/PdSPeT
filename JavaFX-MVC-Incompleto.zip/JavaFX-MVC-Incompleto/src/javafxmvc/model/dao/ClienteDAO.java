package javafxmvc.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafxmvc.model.domain.Customers;

public class ClienteDAO {

  private Connection con;

    public Connection getConnection() {
        return con;
    }

    public void setConnection(Connection connection) {
        this.con = connection;
    }
    public boolean inserir(Customers cliente) {
       String sql = "INSERT INTO  Customers(CustomerID,CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax) VALUES (?,?,?,?,?,?,?,?,?,?,?);";

        try {  // Connection con = Conexao.conectar();//conexao com o banco de dados dentro dessa classe
            PreparedStatement stmt = con.prepareStatement(sql);//os pedidos que estao no banco de dados
            ResultSet rs = stmt.executeQuery();//armazenar o resultado deste select


            stmt.setString(1, cliente.getCustomerID());
            stmt.setString(2, cliente.getCompanyName());
            stmt.setString(3, cliente.getContactName());
            stmt.setString(4, cliente.getContactTitle());
            stmt.setString(5, cliente.getAddress());
            stmt.setString(6, cliente.getCity());
            stmt.setString(7, cliente.getRegion());
            stmt.setString(8, cliente.getPostalCode());
            stmt.setString(9, cliente.getCountry());
            stmt.setString(10, cliente.getPhone());
            stmt.setString(11, cliente.getFax());
            stmt.execute();
            return true;
            //return string mensagem : Cadastrado
        } catch (Exception e) {
          e.printStackTrace();
          
            return false;
        }
    }

    public boolean alterar(Customers cliente) {
        String sql = "UPDATE  Customers SET CompanyName=?,ContactName=?,ContactTitle=?,Address=?,City=?,Region=?,PostalCode=?,Country=?,Phone=?,Fax=? WHERE CustomerID=?;";

        try {
             // Connection con = Conexao.conectar();//conexao com o banco de dados dentro dessa classe
            PreparedStatement stmt = con.prepareStatement(sql);//os pedidos que estao no banco de dados
            ResultSet rs = stmt.executeQuery();//armazenar o resultado deste select

            stmt.setString(1, cliente.getCompanyName());
            stmt.setString(2, cliente.getContactName());
            stmt.setString(3, cliente.getContactTitle());
            stmt.setString(4, cliente.getAddress());
            stmt.setString(5, cliente.getCity());
            stmt.setString(6, cliente.getRegion());
            stmt.setString(7, cliente.getPostalCode());
            stmt.setString(8, cliente.getCountry());
            stmt.setString(9, cliente.getPhone());
            stmt.setString(10, cliente.getFax());
            stmt.execute();
            return true;

        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);

            return false;
        }
    }

    public boolean remover(Customers cliente) {
        String sql = "DELETE FROM  Customers Where CustomerID?;";
        try {  
            PreparedStatement stmt = con.prepareStatement(sql);//os pedidos que estao no banco de dados
            ResultSet rs = stmt.executeQuery();//armazenar o resultado deste select

            stmt.setString(1, cliente.getCustomerID());
            stmt.execute();
        } catch (SQLException e) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, e);

            return false;
        }

        return true;
    }

    public List<Customers> listar() { 
        
     List<Customers> retorno = new ArrayList<Customers>();
        String sql = "SELECT * FROM Customers ;";
   
           
        try {
            PreparedStatement stmt = con.prepareStatement(sql);//os pedidos que estao no banco de dados
            ResultSet rs = stmt.executeQuery();//armazenar o resultado deste select

            while (rs.next()) {

                Customers cliente = new Customers();
                cliente.setCustomerID(rs.getString("CustomerID"));
                cliente.setCompanyName(rs.getString("CompanyName"));
                cliente.setContactName(rs.getString("ContactName"));
                cliente.setContactTitle(rs.getString("ContactTitle"));
                cliente.setAddress(rs.getString("Address"));
                cliente.setCity(rs.getString("City"));
                cliente.setRegion(rs.getString("Region"));
                cliente.setPostalCode(rs.getString("PostalCode"));
                cliente.setCountry(rs.getString("Country"));
                cliente.setPhone(rs.getString("Phone"));
                cliente.setFax(rs.getString("Fax"));
                retorno.add(cliente);

            }
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
     
    }

    public Customers buscar(Customers cliente) {
      String sql = "SELECT * FROM Customers WHERE CustomerID=? ;";
        Customers retorno = new Customers();
        try {  
            PreparedStatement stmt = con.prepareStatement(sql);//os pedidos que estao no banco de dados
            ResultSet rs = stmt.executeQuery();//armazenar o resultado deste select

            if (rs.next()) {

                cliente.setCompanyName(rs.getString("CompanyName"));
                cliente.setContactName(rs.getString("ContactName"));
                cliente.setContactTitle(rs.getString("ContactTitle"));
                cliente.setAddress(rs.getString("Address"));
                cliente.setCity(rs.getString("City"));
                cliente.setRegion(rs.getString("Region"));
                cliente.setPostalCode(rs.getString("PostalCode"));
                cliente.setCountry(rs.getString("Country"));
                cliente.setPhone(rs.getString("Phone"));
                cliente.setFax(rs.getString("Fax"));

                retorno = cliente;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
    }
}
