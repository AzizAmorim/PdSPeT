/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxmvc.model.domain;

import java.io.Serializable;

/**
 *
 * @author thais
 */
public class Shippers implements Serializable {

    private int shipperID;
    private String companyName;
    private String phone;

//METODO PRA VER SE É NULO ,ESPAÇO em branco verefica com metodos fora do construtor e chamar eles dentro antes de contruir
    public Shippers(int shipperID, String companyName, String phone) {
        this.shipperID = shipperID;
        this.companyName = companyName;
        this.phone = phone;
    }

    public Shippers() {
    }

    /**
     * @return the shipperID
     */
    public int getShipperID() {
        return shipperID;
    }

    /**
     * @param shipperID the shipperID to set
     */
    public void setShipperID(int shipperID) {
        this.shipperID = shipperID;
    }

    /**
     * @return the companyName
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * @param companyName the companyName to set
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    /**
     * @return the phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * @param phone the phone to set
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String toString() {
        return "Shippers:"
                + "[ shipperID ="
                + shipperID
                + ",CompanyName = " + companyName
                + " ,Phone =" + phone + "]";
    }
}
