/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxmvc.model.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 *
 * @author thais
 */
public class Orders implements Serializable {

    private int orderID;
    private int customerID;
    private int employeeID;
    private java.sql.Timestamp orderDate;
    private java.sql.Timestamp requiredDate;
    private java.sql.Timestamp shippedDate; //procurar saber como lidar //no controller é que ha as verificaçoes
    private int shipVia;
    private java.math.BigDecimal freight;
    private String shipName;
    private String shipAddress;
    private String shipCity;
    private String shipRegion;
    private String shipPostalCode;
    private String shipCountry;

    public Orders() {

    }

    public Orders(int orderID, int customerID, int employeeID, Timestamp orderDate, Timestamp requiredDate, Timestamp shippedDate, int shipVia, BigDecimal freight, String shipName, String shipAddress, String shipCity, String shipRegion, String shipPostalCode, String shipCountry) {
        this.orderID = orderID;
        this.customerID = customerID;
        this.employeeID = employeeID;
        this.orderDate = orderDate;
        this.requiredDate = requiredDate;
        this.shippedDate = shippedDate;
        this.shipVia = shipVia;
        this.freight = freight;
        this.shipName = shipName;
        this.shipAddress = shipAddress;
        this.shipCity = shipCity;
        this.shipRegion = shipRegion;
        this.shipPostalCode = shipPostalCode;
        this.shipCountry = shipCountry;
    }

    /**
     * @return the OrderID
     */
    public int getOrderID() {
        return orderID;
    }

    /**
     * @param OrderID the OrderID to set
     */
    public void setOrderID(int OrderID) {
        this.orderID = OrderID;
    }

    /**
     * @return the CustomerID
     */
    public int getCustomerID() {
        return customerID;
    }

    /**
     * @param CustomerID the CustomerID to set
     */
    public void setCustomerID(int CustomerID) {
        this.customerID = CustomerID;
    }

    /**
     * @return the EmployeeID
     */
    public int getEmployeeID() {
        return employeeID;
    }

    /**
     * @param EmployeeID the EmployeeID to set
     */
    public void setEmployeeID(int EmployeeID) {
        this.employeeID = EmployeeID;
    }

    /**
     * @return the OrderDate
     */
    public java.sql.Timestamp getOrderDate() {
        return orderDate;
    }

    /**
     * @param OrderDate the OrderDate to set
     */
    public void setOrderDate(java.sql.Timestamp OrderDate) {
        this.orderDate = OrderDate;
    }

    /**
     * @return the RequiredDate
     */
    public java.sql.Timestamp getRequiredDate() {
        return requiredDate;
    }

    /**
     * @param RequiredDate the RequiredDate to set
     */
    public void setRequiredDate(java.sql.Timestamp RequiredDate) {
        this.requiredDate = RequiredDate;
    }

    /**
     * @return the ShippedDate
     */
    public java.sql.Timestamp getShippedDate() {
        return shippedDate;
    }

    /**
     * @param ShippedDate the ShippedDate to set
     */
    public void setShippedDate(java.sql.Timestamp ShippedDate) {
        this.shippedDate = ShippedDate;
    }

    /**
     * @return the ShipVia
     */
    public int getShipVia() {
        return shipVia;
    }

    /**
     * @param ShipVia the ShipVia to set
     */
    public void setShipVia(int ShipVia) {
        this.shipVia = ShipVia;
    }

    /**
     * @return the Freight
     */
    public java.math.BigDecimal getFreight() {
        return freight;
    }

    /**
     * @param Freight the Freight to set
     */
    public void setFreight(java.math.BigDecimal Freight) {
        this.freight = Freight;
    }

    /**
     * @return the ShipName
     */
    public String getShipName() {
        return shipName;
    }

    /**
     * @param ShipName the ShipName to set
     */
    public void setShipName(String ShipName) {
        this.shipName = ShipName;
    }

    /**
     * @return the ShipAddress
     */
    public String getShipAddress() {
        return shipAddress;
    }

    /**
     * @param ShipAddress the ShipAddress to set
     */
    public void setShipAddress(String ShipAddress) {
        this.shipAddress = ShipAddress;
    }

    /**
     * @return the ShipCity
     */
    public String getShipCity() {
        return shipCity;
    }

    /**
     * @param ShipCity the ShipCity to set
     */
    public void setShipCity(String ShipCity) {
        this.shipCity = ShipCity;
    }

    /**
     * @return the ShipRegion
     */
    public String getShipRegion() {
        return shipRegion;
    }

    /**
     * @param ShipRegion the ShipRegion to set
     */
    public void setShipRegion(String ShipRegion) {
        this.shipRegion = ShipRegion;
    }

    /**
     * @return the ShipPostalCode
     */
    public String getShipPostalCode() {
        return shipPostalCode;
    }

    /**
     * @param ShipPostalCode the ShipPostalCode to set
     */
    public void setShipPostalCode(String ShipPostalCode) {
        this.shipPostalCode = ShipPostalCode;
    }

    /**
     * @return the ShipCountry
     */
    public String getShipCountry() {
        return shipCountry;
    }

    /**
     * @param ShipCountry the ShipCountry to set
     */
    public void setShipCountry(String ShipCountry) {
        this.shipCountry = ShipCountry;
    }

    @Override
    public String toString() {
        return "Order:"
                + "["
                + "orderID;=" + orderID
                + ",customerID=" + customerID
                + ",employeeID =" + employeeID
                + ",requiredDate=" + requiredDate
                + "shippedDate=" + shippedDate
                + ",shipVia = " + shipVia
                + ",freight= " + freight
                + ",shipName = " + shipName
                + ",shipAddress = " + shipAddress
                + ",shipCity = " + shipCity
                + ",shipRegion" + shipRegion
                + ",shipPostalCode" + shipPostalCode
                + " shipCountry =" + shipCountry
                + "]";

    }

}
