
package javafxmvc.model.domain;

import java.io.Serializable;

/**
 *
 * @author thais
 */
public class Categories implements Serializable {

    private int categoryID;
    private String categoryName;
    private String description;
    private byte[] picture;

    public Categories(int categoryID, String categoryName, String description, byte[] picture) {
        this.categoryID = categoryID;
        this.categoryName = categoryName;
        this.description = description;
        this.picture = picture;
    }

    public Categories() {
    }

    /**
     * @return the categoryID
     */
    public int getCategoryID() {
        return categoryID;
    }

    /**
     * @param categoryID the categoryID to set
     */
    public void setCategoryID(int categoryID) {
        this.categoryID = categoryID;
    }

    /**
     * @return the categoryName
     */
    public String getCategoryName() {
        return categoryName;
    }

    /**
     * @param categoryName the categoryName to set
     */
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the picture
     */
    public byte[] getPicture() {
        return picture;
    }

    /**
     * @param picture the picture to set
     */
    public void setPicture(byte[] picture) {
        this.picture = picture;
    }

    @Override
    public String toString() {
        return " Category:"
                + "["
                + " Categoryid = " + getCategoryID()
                + ",CompanyName = " + getCategoryName()
                + "ContactName =" + getDescription()
                + ",ContactTitle = " + getPicture()
                + "]";

    }
}
