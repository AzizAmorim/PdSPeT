/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxmvc.model.database;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {

    private static final String urlConn = "jdbc:sqlserver://localhost:1433;instanceName=SQLEXPRESS;databaseName=Northwind;encrypt=false;";

    private static Connection conexao;

    public static Connection conectar() {

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            conexao = DriverManager.getConnection(urlConn, "thais", "123A");
            System.out.println("Conectado ");
        } catch (Exception e) {
            e.printStackTrace();
        }

        return conexao;
    }

    public static void desconectar() {
        try {
            conexao.close();
            System.out.println("Desconectando - fechando a conexao ");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
